@echo off
setlocal
cd /d "%~dp0"
title ShopNova E-commerce Setup

echo.
echo ==========================================
echo       SHOPNOVA E-COMMERCE STARTER
echo ==========================================
echo.

if not exist "package.json" (
  echo ERROR: package.json was not found in this folder.
  echo Please extract the ZIP using "Extract All" and open the folder
  echo that directly contains package.json, index.html, and src.
  echo.
  pause
  exit /b 1
)

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed or not added to PATH.
  echo Install the LTS version from https://nodejs.org/
  echo Then close and reopen VS Code and run this file again.
  echo.
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm was not found. Reinstall Node.js LTS and enable PATH.
  echo.
  pause
  exit /b 1
)

echo Node version:
node --version
echo npm version:
npm --version
echo.
if not exist "node_modules" (
  echo Installing project dependencies. This may take a few minutes...
  call npm install
  if errorlevel 1 (
    echo.
    echo Dependency installation failed. Check your internet connection
    echo and Node.js version, then try again.
    pause
    exit /b 1
  )
) else (
  echo Dependencies already exist. Skipping installation.
)

echo.
echo Starting ShopNova...
echo Keep this window open while using the website.
echo Open http://127.0.0.1:5173 in your browser if it does not open automatically.
echo.
call npm run dev
echo.
echo The development server has stopped.
pause
