import React, { useEffect, useMemo, useState } from 'react';
import {
  Search, ShoppingBag, Heart, UserRound, Menu, X, SlidersHorizontal,
  ChevronDown, Star, Plus, Minus, Trash2, ArrowRight, Check, Truck,
  ShieldCheck, RotateCcw, Sparkles, Moon, Sun, PackageCheck
} from 'lucide-react';
import { products } from './data.js';

const money = (n) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
const categories = ['All products', 'Electronics', 'Fashion', 'Home', 'Accessories', 'Beauty'];

function App() {
  const [cart, setCart] = useState(() => JSON.parse(localStorage.getItem('shopnova-cart') || '{}'));
  const [wishlist, setWishlist] = useState(() => JSON.parse(localStorage.getItem('shopnova-wishlist') || '[]'));
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All products');
  const [sort, setSort] = useState('featured');
  const [maxPrice, setMaxPrice] = useState(7000);
  const [minRating, setMinRating] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [wishlistOnly, setWishlistOnly] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [coupon, setCoupon] = useState('');
  const [couponApplied, setCouponApplied] = useState(false);
  const [toast, setToast] = useState('');
  const [dark, setDark] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [email, setEmail] = useState('');
  const [newsletterDone, setNewsletterDone] = useState(false);

  useEffect(() => localStorage.setItem('shopnova-cart', JSON.stringify(cart)), [cart]);
  useEffect(() => localStorage.setItem('shopnova-wishlist', JSON.stringify(wishlist)), [wishlist]);

  const notify = (message) => {
    setToast(message);
    window.clearTimeout(window.__shopnovaToast);
    window.__shopnovaToast = window.setTimeout(() => setToast(''), 2400);
  };

  const visibleProducts = useMemo(() => {
    let list = products.filter(p => {
      const matchesQuery = `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(query.toLowerCase());
      const matchesCategory = category === 'All products' || p.category === category;
      const matchesPrice = p.price <= maxPrice;
      const matchesRating = !minRating || p.rating >= 4.5;
      const matchesWishlist = !wishlistOnly || wishlist.includes(p.id);
      return matchesQuery && matchesCategory && matchesPrice && matchesRating && matchesWishlist;
    });
    if (sort === 'price-low') list.sort((a,b) => a.price - b.price);
    if (sort === 'price-high') list.sort((a,b) => b.price - a.price);
    if (sort === 'rating') list.sort((a,b) => b.rating - a.rating);
    if (sort === 'discount') list.sort((a,b) => (b.oldPrice-b.price) - (a.oldPrice-a.price));
    return list;
  }, [query, category, maxPrice, minRating, wishlistOnly, wishlist, sort]);

  const cartItems = Object.entries(cart).map(([id, qty]) => ({ product: products.find(p => p.id === Number(id)), qty })).filter(x => x.product && x.qty > 0);
  const cartCount = cartItems.reduce((sum, x) => sum + x.qty, 0);
  const subtotal = cartItems.reduce((sum, x) => sum + x.product.price * x.qty, 0);
  const discount = couponApplied ? Math.round(subtotal * 0.10) : 0;
  const shipping = subtotal === 0 || subtotal >= 1999 ? 0 : 99;
  const total = subtotal - discount + shipping;

  const addToCart = (id, qty = 1) => {
    setCart(prev => ({ ...prev, [id]: (prev[id] || 0) + qty }));
    notify('Added to your bag');
  };
  const updateQty = (id, delta) => setCart(prev => {
    const next = { ...prev, [id]: (prev[id] || 0) + delta };
    if (next[id] <= 0) delete next[id];
    return next;
  });
  const toggleWishlist = (id) => {
    const already = wishlist.includes(id);
    setWishlist(prev => already ? prev.filter(x => x !== id) : [...prev, id]);
    notify(already ? 'Removed from wishlist' : 'Saved to wishlist');
  };
  const resetFilters = () => { setQuery(''); setCategory('All products'); setMaxPrice(7000); setMinRating(false); setWishlistOnly(false); setSort('featured'); };
  const applyCoupon = () => {
    if (coupon.trim().toUpperCase() === 'WELCOME10') { setCouponApplied(true); notify('10% discount applied!'); }
    else { setCouponApplied(false); notify('Try code WELCOME10'); }
  };
  const placeOrder = (e) => {
    e.preventDefault();
    setOrderPlaced(true);
    setCart({});
    setCouponApplied(false);
    setCoupon('');
  };

  return (
    <div className={dark ? 'app dark' : 'app'}>
      <div className="announcement"><Sparkles size={14}/> A little something for your everyday <span>·</span> Free shipping over ₹1,999</div>
      <header className="header">
        <button className="icon-btn mobile-menu-btn" aria-label="Open menu" onClick={() => setMobileMenu(!mobileMenu)}><Menu /></button>
        <a className="brand" href="#home" onClick={() => { setWishlistOnly(false); setCategory('All products'); }}><span className="brand-mark">s</span> shopnova<span className="brand-dot">.</span></a>
        <nav className={mobileMenu ? 'nav nav-open' : 'nav'}>
          <a href="#shop" onClick={() => { setCategory('All products'); setWishlistOnly(false); setMobileMenu(false); }}>Shop</a>
          <a href="#shop" onClick={() => { setCategory('Electronics'); setWishlistOnly(false); setMobileMenu(false); }}>Electronics</a>
          <a href="#shop" onClick={() => { setCategory('Fashion'); setWishlistOnly(false); setMobileMenu(false); }}>Fashion</a>
          <a href="#story" onClick={() => setMobileMenu(false)}>Our story</a>
        </nav>
        <div className="header-actions">
          <label className="search-box"><Search size={17}/><input value={query} onChange={e => {setQuery(e.target.value); setWishlistOnly(false);}} placeholder="Search products..." aria-label="Search products"/>{query && <button onClick={() => setQuery('')} aria-label="Clear search"><X size={14}/></button>}</label>
          <button className="icon-btn" title="Toggle theme" onClick={() => setDark(!dark)}>{dark ? <Sun /> : <Moon />}</button>
          <button className="icon-btn wishlist-head" title="View wishlist" onClick={() => {setWishlistOnly(!wishlistOnly); setCategory('All products'); document.getElementById('shop')?.scrollIntoView({behavior:'smooth'});}}><Heart fill={wishlistOnly ? 'currentColor' : 'none'}/><span className="tiny-count">{wishlist.length}</span></button>
          <button className="icon-btn bag-head" title="Open shopping bag" onClick={() => setCartOpen(true)}><ShoppingBag/><span className="count">{cartCount}</span></button>
        </div>
      </header>

      <main id="home">
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-line"></span> GOOD THINGS, EVERY DAY</div>
            <h1>Find your new<br/><em>everyday</em> favorite.</h1>
            <p>Thoughtful essentials, considered design, and little upgrades that make a big difference.</p>
            <div className="hero-buttons"><a className="btn btn-dark" href="#shop">Explore the collection <ArrowRight size={17}/></a><span className="hero-note">Curated for real life.</span></div>
            <div className="hero-social"><div className="avatar-stack"><span>👩🏽</span><span>👨🏻</span><span>👩🏼</span><span>🧑🏾</span></div><div><strong>4.9/5</strong><small>Loved by 2,000+ shoppers</small></div></div>
          </div>
          <div className="hero-art">
            <div className="hero-orbit orbit-one"></div><div className="hero-orbit orbit-two"></div>
            <div className="hero-product hero-product-main"><span>🎧</span><small>THE SOUND EDIT</small></div>
            <div className="hero-product hero-product-side"><span>👜</span></div>
            <div className="floating-note note-top"><Sparkles size={15}/> Small things. Better days.</div>
            <div className="floating-note note-bottom"><span className="green-dot"></span> New season, new favorites</div>
            <div className="hero-sticker">MADE FOR<br/>YOUR EVERYDAY</div>
          </div>
          <div className="hero-bottom"><span>01 — 04</span><div className="hero-progress"><i></i></div><span>SCROLL TO EXPLORE ↓</span></div>
        </section>

        <section className="trust-strip">
          <div><Truck/><span><strong>Free shipping</strong><small>On orders over ₹1,999</small></span></div>
          <div><ShieldCheck/><span><strong>Secure checkout</strong><small>Your details stay safe</small></span></div>
          <div><RotateCcw/><span><strong>Easy returns</strong><small>7-day return window</small></span></div>
          <div><PackageCheck/><span><strong>Quality checked</strong><small>Good things, guaranteed</small></span></div>
        </section>

        <section className="shop-section" id="shop">
          <div className="section-heading">
            <div><div className="eyebrow"><span className="eyebrow-line"></span> THE GOOD STUFF</div><h2>{wishlistOnly ? 'Your wishlist' : 'Shop the collection'}<span className="heading-period">.</span></h2><p>Useful, beautiful, and ready for your everyday.</p></div>
            <div className="shop-controls"><button className={'filter-button ' + (filtersOpen ? 'active' : '')} onClick={() => setFiltersOpen(!filtersOpen)}><SlidersHorizontal size={16}/> Filters {(minRating || maxPrice < 7000) && <span className="filter-dot"></span>}</button><label className="sort-select"><span>Sort by</span><select value={sort} onChange={e => setSort(e.target.value)}><option value="featured">Featured</option><option value="price-low">Price: low to high</option><option value="price-high">Price: high to low</option><option value="rating">Top rated</option><option value="discount">Biggest savings</option></select><ChevronDown size={14}/></label></div>
          </div>
          <div className="category-tabs">{categories.map(c => <button key={c} className={category === c ? 'category-tab selected' : 'category-tab'} onClick={() => {setCategory(c); setWishlistOnly(false);}}>{c}</button>)}</div>
          {filtersOpen && <div className="filter-panel"><div className="price-filter"><label>Maximum price <strong>{money(maxPrice)}</strong></label><input type="range" min="500" max="7000" step="250" value={maxPrice} onChange={e => setMaxPrice(Number(e.target.value))}/><div className="range-labels"><span>₹500</span><span>₹7,000</span></div></div><label className="rating-check"><input type="checkbox" checked={minRating} onChange={e => setMinRating(e.target.checked)}/> Show products rated 4.5+ </label><button className="text-button" onClick={resetFilters}>Reset all</button></div>}
          <div className="results-line"><span>{visibleProducts.length} products</span>{(query || category !== 'All products' || wishlistOnly) && <button onClick={resetFilters}>Clear filters <X size={13}/></button>}</div>
          {visibleProducts.length ? <div className="product-grid">{visibleProducts.map(p => <article className="product-card" key={p.id}>
            <div className="product-image" style={{'--product-bg':p.color}} onClick={() => setSelectedProduct(p)} role="button" tabIndex="0" onKeyDown={e => e.key === 'Enter' && setSelectedProduct(p)}>
              {p.tag && <span className="product-tag">{p.tag}</span>}
              <button className={'heart-button ' + (wishlist.includes(p.id) ? 'hearted' : '')} aria-label="Toggle wishlist" onClick={e => {e.stopPropagation(); toggleWishlist(p.id);}}><Heart size={17} fill={wishlist.includes(p.id) ? 'currentColor' : 'none'}/></button>
              <span className="product-emoji">{p.emoji}</span>
              <button className="quick-view" onClick={e => {e.stopPropagation(); setSelectedProduct(p);}}>Quick view <ArrowRight size={14}/></button>
            </div>
            <div className="product-info"><div className="product-meta"><span>{p.category}</span><span className="rating"><Star size={12} fill="currentColor"/> {p.rating} <small>({p.reviews})</small></span></div><button className="product-name" onClick={() => setSelectedProduct(p)}>{p.name}</button><div className="product-bottom"><div className="price-wrap"><strong>{money(p.price)}</strong><del>{money(p.oldPrice)}</del></div><button className="add-button" onClick={() => addToCart(p.id)} aria-label={'Add ' + p.name + ' to bag'}><Plus size={18}/></button></div></div>
          </article>)}</div> : <div className="empty-state"><span>🔎</span><h3>No products found</h3><p>Try a different search or reset your filters.</p><button className="btn btn-dark" onClick={resetFilters}>Show all products</button></div>}
          <div className="shop-footnote"><span>✳</span> Good picks. Fair prices. No fuss.</div>
        </section>

        <section className="promo-banner" id="story"><div className="promo-art"><span>🌿</span><div className="promo-circle"></div><div className="promo-mini-card">THE<br/>SLOW<br/>DOWN</div></div><div className="promo-copy"><div className="eyebrow"><span className="eyebrow-line"></span> A NOTE FROM US</div><h2>Less noise.<br/><em>More good stuff.</em></h2><p>We believe the things you use every day should feel a little special. That's why we focus on considered design, useful details, and quality that lasts.</p><a href="#shop" className="text-link">Meet your next favorite <ArrowRight size={16}/></a></div></section>

        <section className="newsletter"><div className="newsletter-icon">✳</div><div className="newsletter-copy"><h2>A good email, now and then.</h2><p>New arrivals, thoughtful finds, and 10% off your first order.</p></div>{newsletterDone ? <div className="newsletter-success"><Check size={18}/> You're on the list!</div> : <form className="newsletter-form" onSubmit={e => {e.preventDefault(); if(email.includes('@')) {setNewsletterDone(true); notify('Welcome to the list!');} else notify('Please enter a valid email');}}><input type="email" required placeholder="Your email address" value={email} onChange={e => setEmail(e.target.value)}/><button type="submit">Sign me up <ArrowRight size={15}/></button></form>}</section>
      </main>

      <footer className="footer"><a className="brand" href="#home"><span className="brand-mark">s</span> shopnova<span className="brand-dot">.</span></a><p>Everyday essentials, a little more special.</p><div className="footer-links"><a href="#shop">Shop</a><a href="#story">Our story</a><a href="mailto:hello@shopnova.example">Contact</a><a href="#home">Back to top ↑</a></div><small>© 2026 ShopNova. Demo storefront for learning purposes.</small></footer>

      {cartOpen && <div className="overlay" onMouseDown={e => e.target === e.currentTarget && setCartOpen(false)}><aside className="drawer">
        <div className="drawer-head"><div><span className="eyebrow">YOUR GOOD FINDS</span><h2>Your bag <span>({cartCount})</span></h2></div><button className="icon-btn" onClick={() => setCartOpen(false)} aria-label="Close bag"><X/></button></div>
        {cartItems.length ? <><div className="drawer-items">{cartItems.map(({product:p, qty}) => <div className="cart-item" key={p.id}><div className="cart-thumb" style={{background:p.color}}>{p.emoji}</div><div className="cart-item-info"><strong>{p.name}</strong><small>{p.category}</small><b>{money(p.price)}</b><div className="qty-control"><button onClick={() => updateQty(p.id,-1)} aria-label="Decrease quantity"><Minus size={13}/></button><span>{qty}</span><button onClick={() => updateQty(p.id,1)} aria-label="Increase quantity"><Plus size={13}/></button></div></div><button className="remove-button" onClick={() => setCart(prev => {const next={...prev};delete next[p.id];return next;})} aria-label="Remove item"><Trash2 size={16}/></button></div>)}</div>
          <div className="coupon-row"><input value={coupon} onChange={e => setCoupon(e.target.value)} placeholder="Promo code (try WELCOME10)"/><button onClick={applyCoupon}>{couponApplied ? 'Applied ✓' : 'Apply'}</button></div>{couponApplied && <p className="coupon-success"><Check size={13}/> WELCOME10 applied — 10% off</p>}
          <div className="shipping-hint">{subtotal >= 1999 ? '🎉 You unlocked free shipping!' : `Add ${money(1999-subtotal)} more for free shipping.`}<div className="shipping-progress"><i style={{width:Math.min(100, subtotal/1999*100)+'%'}}/></div></div>
          <div className="cart-summary"><div><span>Subtotal</span><strong>{money(subtotal)}</strong></div>{discount > 0 && <div className="discount-line"><span>Discount</span><strong>−{money(discount)}</strong></div>}<div><span>Shipping</span><strong>{shipping === 0 ? 'FREE' : money(shipping)}</strong></div><div className="total-line"><span>Total</span><strong>{money(total)}</strong></div><button className="btn btn-dark checkout-button" onClick={() => {setCheckoutOpen(true);setOrderPlaced(false);}}>Continue to checkout <ArrowRight size={17}/></button><p className="secure-note"><ShieldCheck size={14}/> Secure demo checkout · No real payment</p></div>
        </> : <div className="empty-bag"><span>🛍️</span><h3>Your bag is taking a break.</h3><p>Find something lovely to bring home.</p><button className="btn btn-dark" onClick={() => setCartOpen(false)}>Continue shopping</button></div>}
      </aside></div>}

      {selectedProduct && <div className="overlay modal-overlay" onMouseDown={e => e.target === e.currentTarget && setSelectedProduct(null)}><div className="product-modal"><button className="modal-close icon-btn" onClick={() => setSelectedProduct(null)}><X/></button><div className="modal-product-art" style={{background:selectedProduct.color}}><span>{selectedProduct.emoji}</span></div><div className="modal-product-copy"><span className="eyebrow">{selectedProduct.category}</span><h2>{selectedProduct.name}</h2><div className="modal-rating"><Star size={14} fill="currentColor"/> {selectedProduct.rating} <span>({selectedProduct.reviews} reviews)</span></div><div className="modal-price">{money(selectedProduct.price)} <del>{money(selectedProduct.oldPrice)}</del></div><p>{selectedProduct.description}</p><div className="modal-perks"><span><Truck size={15}/> Free shipping over ₹1,999</span><span><RotateCcw size={15}/> Easy 7-day returns</span></div><button className="btn btn-dark modal-add" onClick={() => {addToCart(selectedProduct.id); setSelectedProduct(null); setCartOpen(true);}}>Add to bag <ShoppingBag size={17}/></button><button className="modal-wishlist" onClick={() => toggleWishlist(selectedProduct.id)}><Heart size={16} fill={wishlist.includes(selectedProduct.id) ? 'currentColor' : 'none'}/>{wishlist.includes(selectedProduct.id) ? 'Saved to wishlist' : 'Add to wishlist'}</button></div></div></div>}

      {checkoutOpen && <div className="overlay modal-overlay"><div className="checkout-modal"><button className="modal-close icon-btn" onClick={() => setCheckoutOpen(false)}><X/></button>{orderPlaced ? <div className="order-success"><div className="success-icon"><Check size={30}/></div><h2>Order received!</h2><p>This is a demo checkout, so no payment was taken. Your sample order is complete.</p><span>Order reference: SN-{Math.floor(100000 + Math.random()*899999)}</span><button className="btn btn-dark" onClick={() => {setCheckoutOpen(false);setCartOpen(false);setOrderPlaced(false);}}>Back to shopping</button></div> : <><span className="eyebrow">ALMOST YOURS</span><h2>Checkout</h2><p className="checkout-subtitle">Enter sample details to complete the demo order.</p><form onSubmit={placeOrder} className="checkout-form"><label>Full name<input required placeholder="Your name" autoComplete="name"/></label><label>Email address<input required type="email" placeholder="you@example.com" autoComplete="email"/></label><label>Delivery address<textarea required placeholder="House no., street, city, PIN code" rows="3" autoComplete="street-address"/></label><label>Payment method<select><option>Cash on delivery (demo)</option><option>UPI (demo only)</option><option>Card (demo only)</option></select></label><div className="checkout-total"><span>Order total</span><strong>{money(total)}</strong></div><button className="btn btn-dark" type="submit">Place demo order <ArrowRight size={17}/></button><small><ShieldCheck size={13}/> No real payment or order is created.</small></form></>}</div></div>}

      {toast && <div className="toast"><Check size={16}/>{toast}</div>}
    </div>
  );
}

export default App;
