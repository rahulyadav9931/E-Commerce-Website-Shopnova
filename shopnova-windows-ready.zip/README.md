# ShopNova — React E-commerce Frontend

## Quick start on Windows

1. Extract this ZIP with **Right-click → Extract All**.
2. Open the extracted `shopnova-ecommerce` folder. `package.json` must be directly inside it.
3. Double-click `START-WINDOWS.bat`.
4. Wait for dependencies to install and Vite to start.
5. Open `http://127.0.0.1:5173` in your browser.
6. Keep the black terminal window open while testing the website.

If Windows says Node/npm is missing, install the **Node.js LTS** version from https://nodejs.org/, then close and reopen VS Code or run the batch file again.

## Manual VS Code commands

Open the terminal in the folder containing `package.json`, then run:

```powershell
npm install
npm run dev
```

For a production build:

```powershell
npm run build
```

## Features

- Responsive product catalogue
- Search, category filters, maximum-price filter, rating filter, and sorting
- Product quick-view modal
- Wishlist saved in browser localStorage
- Cart quantities, remove item, subtotal, shipping, total
- Demo `WELCOME10` coupon for 10% off
- Demo checkout form and confirmation
- Dark mode toggle
- Newsletter signup interaction
- Toast messages and empty states

## Project files

- `src/App.jsx` — application and interactions
- `src/data.js` — sample product catalogue
- `src/styles.css` — responsive styling
- `src/main.jsx` — React entry point
- `index.html` — HTML entry point
- `package.json` — dependencies and commands
- `START-WINDOWS.bat` — Windows setup and run helper

## Important limitations

This is a frontend learning demo. Checkout does not charge a payment method or create a real order. No backend, real authentication, database, or live inventory is included. Cart and wishlist use localStorage in this browser. Product visuals use emoji placeholders and CSS backgrounds.
